START TRANSACTION;

UPDATE tblVersion set major=3, minor=2, subminor=0;

COMMIT;
