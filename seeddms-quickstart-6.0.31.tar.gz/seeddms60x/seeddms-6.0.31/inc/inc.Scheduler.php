<?php
/**
 * Initialize scheduler
 *
 * @category   DMS
 * @package    SeedDMS
 * @license    GPL 2
 * @version    @version@
 * @author     Uwe Steinmann <uwe@steinmann.cx>
 * @copyright  Copyright (C) 2018 Uwe Steinmann
 * @version    Release: @package_version@
 */

require_once "inc.ClassSchedulerTaskBase.php";
require_once "inc.ClassScheduler.php";
require_once "inc.ClassSchedulerTask.php";

