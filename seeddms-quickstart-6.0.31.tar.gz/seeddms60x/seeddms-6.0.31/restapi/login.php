<form action="index.php/login" method="post">
<input type="text" name="user" value="" />
<input type="password" name="pass" value="" />
<input type="submit" value="Login" />
</form>
