<?php
$__lang['de_DE'] = array(
	'folder_contents' => 'Dies war mal "Ordner enthält". Wurde von sample Extension geändert.',
	'task_example_example_email' => 'Email',
);
$__lang['en_GB'] = array(
	'folder_contents' => 'This used to be "Folder contents". Was changed by sample Extension.',
	'task_example_example_email' => 'Email',
);
